echo "obikhan"
sudo yum  update -y

docker ps
docker ps -a

docker --version

